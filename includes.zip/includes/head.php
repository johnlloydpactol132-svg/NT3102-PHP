<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fantasy Journey</title><link rel="stylesheet" href="assets/style.css"></head><body>
